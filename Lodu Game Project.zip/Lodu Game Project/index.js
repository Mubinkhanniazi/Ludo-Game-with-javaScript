

luduGames = () => {
    const play1 = Math.floor(Math.random() * 6) + 1;
    const play1dice = `img/dice${play1}.png`;
    // const play1dice = "img/dice"+play1+".png";
    document.getElementById("check1").setAttribute('src', play1dice);

    const play2 = Math.floor(Math.random() * 6) + 1;
    const play2dice = `img/dice${play2}.png`;
    // const play1dice = "img/dice"+play1+".png";
    document.getElementById("check2").setAttribute('src', play2dice);

if(play1 > play2){
    document.querySelector('h1').innerHTML = "Player1 won";
}else if(play1 < play2){
    document.querySelector('h1').innerHTML = "Player2 won";
}else{
    document.querySelector('h1').innerHTML = "DRAW";
}

if(play1 > play2){
    document.querySelector('h2').innerHTML = "CONGRATULATION";
    document.getElementById("bg").style.background = "green";
    document.getElementById("cong").innerHTML = "YOU LOSS";
    document.getElementById("bg2").style.background = "red";
}else if(play1 < play2){
    document.querySelector('h2').innerHTML = "YOU LOSS";
    document.getElementById("bg").style.background = "red";
    document.getElementById("cong").innerHTML = "CONGRATULATION";
    document.getElementById("bg2").style.background = "green";
}else{
    document.querySelector('h2').innerHTML = "DRAW";
    document.getElementById("bg").style.background = "aqua";
    document.getElementById("bg2").style.background = "aqua";
    document.getElementById("cong").innerHTML = "DRAW";
}




} 
